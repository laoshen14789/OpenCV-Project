#include<opencv2/opencv.hpp>
#include<math.h>
#include"Serial.h"

#define aaa "USB Camera"
using namespace cv;
using namespace std;
int zzz,ooo;
//string a;
Rect mouse;
char P[8];
char A[8];
void jizuobiao(float x, float y, int* p, int* angle);
void on_MouseHandle(int event, int x, int y, int flags, void* param);
void Drawline(Mat img, Point start, Point end);
int connectstate;
HANDLE hCom;//���ھ��
int main(int argc, char** argv) {
	serial_connect(hCom, (wchar_t*)L"\\\\.\\COM8", CBR_115200);//���ӵ�COM10��������115200
	Mat frame;
	VideoCapture capture;
	capture.open(0);
	mouse = Rect(-1, -1, 0, 0);
	namedWindow(aaa);
	setMouseCallback(aaa, on_MouseHandle, (void*)& frame);
	int a=10;
	while (1) {
		capture >> frame;
		Drawline(frame, Point(0, (frame.rows) / 2), Point(frame.cols, (frame.rows) / 2));
		Drawline(frame, Point((frame.cols) / 2, 0), Point((frame.cols) / 2, frame.rows));
		imshow(aaa, frame);
		jizuobiao(mouse.x - (frame.cols) / 2, -(mouse.y - (frame.rows) / 2),&zzz,&ooo);
		_itoa_s(zzz, P, 10);
		_itoa_s(ooo, A, 10);
		//TXData[0] = zzz;
		//TXData = "asdfg";
		Read(hCom);//�����ڣ�����������������ʾ����
		if (mouse.x && mouse.y > 0)
		{
			//printf("x=%d y=%d\n", mouse.x - (frame.cols) / 2, -(mouse.y - (frame.rows) / 2));
			//printf("p=%d\ angle=%d\n", zzz,ooo);
			if (connectstate != -1) {
				
				//printf("%s\n", TXData);
				//sprintf_s(P, "%d", zzz);
				//sprintf_s(A, "%.1f", ooo);
				//Sleep(2);
				//Write(hCom, (char*)"P", sizeof("P"));//����
				//Sleep(1);
				Write(hCom, P,sizeof(P));//����
				PurgeComm(hCom, PURGE_TXCLEAR);
				Write(hCom, A, sizeof(A));//����
				//Write(hCom, (char*)"A", sizeof("A"));//����
				//Write(hCom, A, sizeof(A[30]));//����
				//Read(hCom);//�����ڣ�����������������ʾ����
				//CloseHandle(hCom);//�رմ���
				//Write(hCom, TXData, sizeof(a));//����
				//PurgeComm(hCom, PURGE_TXCLEAR);
				PurgeComm(hCom, PURGE_RXCLEAR);
			}
			else {
				printf("��������ʧ��!\n");
			}			
		}
		waitKey(30);
	}
	return 0;
}

void on_MouseHandle(
	int event,
	int x,
	int y, 
	int flags,
	void* param) {//���ص�����

	Mat& image = *(cv::Mat*) param;
	switch (event) {
	case EVENT_LBUTTONDOWN:
		mouse = Rect(x, y, 0, 0);
		break;
	default: mouse = Rect(0, 0, 0, 0);
	}

}

void Drawline(
	Mat img,
	Point start,
	Point end) {//���ߺ���

	int thickness = 1;
	int lineType = 8;
	line(img, start, end, Scalar(0, 0, 0), thickness, lineType);

}

void jizuobiao(
	float x,
	float y,
	int *p,
	int *angle) {//ֱ������ת������
	float pp;
	*p = (sqrt(x * x + y * y))*10000;
	pp = sqrt(x * x + y * y);
	//*p = (int)*p;
	if (y > 0) {
		*angle = ((180 * acos(x / pp)) / 3.14)*10000 ;
		//*angle = (int)*angle;
	}
	else if (y < 0) {
		*angle = (360 - (180 * acos(x / pp)) / 3.14)*10000;
		//*angle = (int)*angle;
	}
}
